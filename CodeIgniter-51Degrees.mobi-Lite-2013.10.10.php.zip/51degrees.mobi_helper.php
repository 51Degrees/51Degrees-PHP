<?php

// Ensures that the code can only be accessed from inside CodeIgniter
if (!defined('BASEPATH')) exit('No direct script access allowed');


if (!function_exists('_51D'))
{
	function _51D()
	{
    	include_once('51Degrees/51Degrees.mobi.php');

    	// Uncomment below to Share usage data with 51Degrees.mobi. Learn more at http://51degrees.mobi/Support/FAQs/UsageData.aspx
    	// include_once('51Degrees/51Degrees.mobi.usage.php');

    	return $_51d;
    }

    function _51DMetadata()
    {
    	include_once('51Degrees/51Degrees.mobi.metadata.php');
    	return $_51d_meta_data;
    }

    function _51DUpdate()
    {
        include_once('51Degrees/Update.php');
        return $result;
    }
}

//
// To load the helper, unzip and extract the solution to /application/helpers/
// Once extracted, to load the helper just add the following line of code to manually load the 51D_helper:
//
// $this->load->helper('51Degrees.mobi');
//
// Alternatively, if you need the variable globally, you can auto-load the helper during system initialization.
// This is done by opening the application/config/autoload.php file and adding the helper to the autoload array, like so:
//
// $autoload['helper'] = array('51Degrees.mobi');
//
// Then to access any key within the variable, first assign the _51D method to a variable (e.g. $_51d = _51d();)
// To access the 51Degrees.mobi metadata, assign the _51DMetadata method to a variable (e.g. $_51DMetadata = _51d_meta_data)
// Now you can use the $_51D as per the 51Degrees.mobi documentation.
//

?>