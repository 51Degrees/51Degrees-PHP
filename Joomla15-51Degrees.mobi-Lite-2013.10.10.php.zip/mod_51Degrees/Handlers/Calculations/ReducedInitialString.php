<?php
/*------------------------------------------------------------------------
# mod_51Degrees - 51Degrees.mobi PHP
# ------------------------------------------------------------------------
# author    51Degrees.mobi
# copyright Copyright 2010 - 2012 51Degrees.mobi Limited
# @license - http://mozilla.org/MPL/2.0/ This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
# Websites: http://51Degrees.mobi/
# Technical Support:  Forum - http://51degrees.mobi/Support/Forum.aspx
-------------
/**
 * See LICENSE.TXT for terms of use and copyright.
 */

/**
 * Insert Function Doc comment here.
 */
function fiftyone_degrees_ReducedInitialString($ua_to_test, $max_initial_string, $tolerance) {
  if ((fiftyone_degrees_StartsWith($_SERVER['HTTP_USER_AGENT'], $ua_to_test) || fiftyone_degrees_StartsWith($ua_to_test, $_SERVER['HTTP_USER_AGENT'])) && $max_initial_string < strlen($ua_to_test)) {
    return strlen($ua_to_test);
  }
  return NULL;
}

/**
 * Insert Function Doc comment here.
 */
function fiftyone_degrees_StartsWith($haystack, $needle) {
  $length = strlen($needle);
  return (substr($haystack, 0, $length) === $needle);
}
