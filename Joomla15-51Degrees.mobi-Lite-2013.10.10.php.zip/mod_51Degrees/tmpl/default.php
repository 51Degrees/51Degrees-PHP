<?php
/**------------------------------------------------------------------------
# mod_51Degrees - 51Degrees.mobi PHP
# ------------------------------------------------------------------------
# author    51Degrees.mobi
# copyright Copyright 2010 - 2012 51Degrees.mobi Limited
# @license - http://mozilla.org/MPL/2.0/ This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
# Websites: http://51Degrees.mobi/
# Technical Support:  Forum - http://51degrees.mobi/Support/Forum.aspx
-------------*/

  // no direct access
  defined('_JEXEC') or die('Restricted access');
?>

  <div class="include_main">
	   <div class="include_wrap">
       <?php
          include(dirname(__FILE__).DS.'../51Degrees.mobi.php');
          echo $_51D['IsMobile'];
       ?>
       <?php
        if ($params->get('showHere', 1))
	      {
		      include(dirname(__FILE__).DS.'../51Degrees.mobi.usage.php');
	      }
        if	($params->get('showHome', 1))
        {
          include(dirname(__FILE__).DS.'../51Degrees.mobi.metadata.php');
          echo $_51DMetadata;
        }
      ?>

	 </div>
 </div>