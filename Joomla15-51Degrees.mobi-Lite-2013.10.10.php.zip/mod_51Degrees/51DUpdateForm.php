<?php
/*------------------------------------------------------------------------
# mod_51Degrees - 51Degrees.mobi PHP
# ------------------------------------------------------------------------
# author    51Degrees.mobi
# copyright Copyright 2010 - 2012 51Degrees.mobi Limited
# @license - http://mozilla.org/MPL/2.0/ This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
# Websites: http://51Degrees.mobi/
# Technical Support:  Forum - http://51degrees.mobi/Support/Forum.aspx
-------------
/**
 * See LICENSE.TXT for terms of use and copyright.
 */
	include_once('51Degrees.mobi.metadata.php');

	$data_type = $_51d_meta_data["DatasetType"];
	$export_date = $_51d_meta_data["ExportDate"];

?>

<html>

<head>
<title>51Degrees.mobi Data Updater for PHP</title>
<script type="text/javascript" src="51DUpdate.js" ></script>
</head>

<body>
You're currently using <?php echo $data_type; ?> data exported on the <?php echo $export_date; ?>.
Press the button below to attempt an update from 51Degrees.mobi.
<form action="" method="POST" name="ajax">
	<input onclick="fiftyone_degrees_start_updates();" type="BUTTON" value="Update Data"></input>
	<div id="update_message"></div>
</form>

</body>

</html>
