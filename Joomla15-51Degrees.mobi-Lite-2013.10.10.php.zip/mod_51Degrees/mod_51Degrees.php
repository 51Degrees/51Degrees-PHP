<?php
/**
 * See LICENSE.TXT for terms of use and copyright.
 */
/**
 * 51Degrees Module Entry Point
 *
 * @package    51Degrees.mobi
 * @subpackage Modules
 * @link
 * @license        Mozilla, see License.txt
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Include the syndicate functions only once


require( JModuleHelper::getLayoutPath( 'mod_51Degrees' ) );
?>